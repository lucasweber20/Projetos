<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "cadastro";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_GET['search'])) {
        $search=$_GET['search'];

        $sql = "SELECT * FROM pessoas where id like '%$search%' or nome like '%$search%'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) { // Retorna o número de linha no conjunto de resultados
            // output data of each row
            while($row = mysqli_fetch_assoc($result)) { // Retorna um array com os resultados do banco
                echo "id: " . $row["id"]. " - Nome: " . $row["nome"] . "<br>";
            }
        } else {
            echo "0 results";
        }
    }
    mysqli_close($conn);
?>